package com.example.webstore.model;

public class Admin extends User {
    public Admin(String userName, String email, String pw) {
        this.userName = userName;
        this.email = email;
        this.pw = pw;
    }

    public Admin(){

    }
}
