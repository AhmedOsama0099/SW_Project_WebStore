package com.example.webstore.Exceptions.login;

public class LoginUserNotFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;

}
