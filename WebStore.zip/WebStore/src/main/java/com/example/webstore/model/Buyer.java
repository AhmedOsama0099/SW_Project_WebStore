package com.example.webstore.model;

public class Buyer extends User {
    public Buyer(String userName, String email, String pw) {
        this.userName = userName;
        this.email = email;
        this.pw = pw;
    }
    public Buyer(){}
}
