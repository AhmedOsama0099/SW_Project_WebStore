package com.example.webstore.Exceptions.signUp;

public class SignUpUserFoundException extends RuntimeException {
    private static final long serialVersionUID = 1L;
}
