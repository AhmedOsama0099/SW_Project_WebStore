package com.example.webstore.model;

public class StoreOwner extends User{
    public StoreOwner(String userName, String email, String pw) {
        this.userName = userName;
        this.email = email;
        this.pw = pw;
    }
    public StoreOwner(){}
}
